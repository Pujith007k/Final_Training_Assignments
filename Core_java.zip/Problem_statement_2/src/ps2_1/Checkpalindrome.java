package ps2_1;
import java.util.Scanner;
public class Checkpalindrome {
	 public static void main(String args[])
	   {
	      String str, rev = "";
	      Scanner b = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str = b.nextLine();
	 
	      int length = str.length();
	 
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + str.charAt(i);
	 
	      if (str.equals(rev))
	         System.out.println(str+" is a palindrome");
	      else
	         System.out.println(str+" is not a palindrome");
	 
	   }

}
